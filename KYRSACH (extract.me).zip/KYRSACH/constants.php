<?php

	define("DB_SERVER", "KYRSACH");
	define("DB_USER", "mysql");
	define("DB_PASS", "mysql");
	define("DB_NAME", "userlistdb");
	?>